<?php
require_once (dirname(dirname(__FILE__)) . '/term.class.php');
class Term_mysql extends Term {}