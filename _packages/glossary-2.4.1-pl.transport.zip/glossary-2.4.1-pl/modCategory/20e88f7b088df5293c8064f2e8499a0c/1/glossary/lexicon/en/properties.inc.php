<?php
/**
 * Properties Lexicon Entries for Glossary
 *
 * @package glossary
 * @subpackage lexicon
 */
$_lang['glossary.glossary.groupTpl'] = 'Template chunk for glossary item groups';
$_lang['glossary.glossary.navItemTpl'] = 'Template chunk for each item in the nav-bar';
$_lang['glossary.glossary.navOuterTpl'] = 'Template chunk for outer nav-bar wrapper';
$_lang['glossary.glossary.outerTpl'] = 'Template chunk for glossary outer wrapper';
$_lang['glossary.glossary.showNav'] = 'Shows a quick-nav bar at the top of the glossary';
$_lang['glossary.glossary.termTpl'] = 'Template chunk for glossary term items';
$_lang['glossary.glossary.toPlaceholder'] = 'If set, the snippet result will be assigned to this placeholder instead of outputting it directly.';
