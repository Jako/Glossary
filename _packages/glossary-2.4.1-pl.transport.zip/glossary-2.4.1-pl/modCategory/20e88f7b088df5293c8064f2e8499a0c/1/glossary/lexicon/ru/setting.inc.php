<?php
/**
 * Setting Lexicon Entries for Glossary
 *
 * @package glossary
 * @subpackage lexicon
 */
$_lang['setting_glossary.debug'] = 'Включить отладку';
$_lang['setting_glossary.debug_desc'] = 'Добавить информацию отладки в журнал ошибок MODX.';
$_lang['setting_glossary.disabledAttributes'] = 'Disabled Attributes';
$_lang['setting_glossary.disabledAttributes_desc'] = '(Comma separated list) Glossary does not replace text inside of this HTML tag attributes.';
$_lang['setting_glossary.fullwords'] = 'Поиск по всему Слова';
$_lang['setting_glossary.fullwords_desc'] = 'Заменить только полные слова глоссарий термина в содержании ресурса.';
$_lang['setting_glossary.html'] = 'Allow HTML';
$_lang['setting_glossary.html_desc'] = 'Allow HTML in the explanation (enables a rich-text editor in the term form).';
$_lang['setting_glossary.resid'] = 'Словарь ресурсов ID';
$_lang['setting_glossary.resid_desc'] = 'ID страницы на которой находится сниппет Glossary.';
$_lang['setting_glossary.sections'] = 'Ограничить разделам';
$_lang['setting_glossary.sections_desc'] = 'Заменить глоссарий терминов только в разделах, помеченных: &lt;!— GlossaryStart --&gt;&lt;!— GlossaryEnd --&gt;.';
$_lang['setting_glossary.sectionsEnd'] = 'Section End Marker';
$_lang['setting_glossary.sectionsEnd_desc'] = 'Marker at the end of a section processed by Glossary. The restriction to marked sections can be activated in the setting \'glossary.sections\'.';
$_lang['setting_glossary.sectionsStart'] = 'Section Start Marker';
$_lang['setting_glossary.sectionsStart_desc'] = 'Marker at the start of a section processed by Glossary. The restriction to marked sections can be activated in the setting \'glossary.sections\'.';
$_lang['setting_glossary.tpl'] = 'Выделите шаблон';
$_lang['setting_glossary.tpl_desc'] = 'Чанк для выделенных терминов.';
