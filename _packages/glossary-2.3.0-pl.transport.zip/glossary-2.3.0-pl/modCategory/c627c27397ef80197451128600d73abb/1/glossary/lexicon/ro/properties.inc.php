<?php
$_lang['prop_glossary.outerTpl_desc'] = 'Chunk-ul pentru lista de termeni';
$_lang['prop_glossary.groupTpl_desc'] = 'Chunk-ul pentru grupurile de termeni';
$_lang['prop_glossary.termTpl_desc'] = 'Chunk-ul pentru termeni';
$_lang['prop_glossary.showNav_desc'] = 'Afișează indexul alfabetic';
$_lang['prop_glossary.navOuterTpl_desc'] = 'Chunk-ul pentru indexul alfabetic';
$_lang['prop_glossary.navItemTpl_desc'] = 'Chunk-ul pentru literele din index';
