<?php
class Term extends xPDOSimpleObject {}