<?php
/**
 * Properties Lexicon Entries for Glossary
 *
 * @package glossary
 * @subpackage lexicon
 */
$_lang['glossary.glossary.groupTpl'] = 'Чанк для групп терминов';
$_lang['glossary.glossary.navItemTpl'] = 'Чанк для букв в алфавитном указателе';
$_lang['glossary.glossary.navOuterTpl'] = 'Чанк для алфавитного указателя';
$_lang['glossary.glossary.outerTpl'] = 'Чанк для списка терминов';
$_lang['glossary.glossary.showNav'] = 'Показать алфавитный указатель';
$_lang['glossary.glossary.termTpl'] = 'Чанк для терминов';
$_lang['glossary.glossary.toPlaceholder'] = 'Если установлено, результат сниппета будет назначен этому плейсхолду вместо его прямого вывода.';
