<?php
$_lang['glossary.' + config.tabtype + '_desc'] = '';
