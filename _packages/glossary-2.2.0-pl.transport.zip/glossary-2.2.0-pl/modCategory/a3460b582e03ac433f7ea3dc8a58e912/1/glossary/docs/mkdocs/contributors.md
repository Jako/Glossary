## Contributors

The Glossary project was started in 2012 by [Alan Pich](https://github.com/alanpich) and is maintained and developed further since 2016 by [Thomas Jakobi](https://github.com/jako).

Many thanks to everyone else who has contributed to this project:

* [@vundicind](https://github.com/vundicind)
* [@sepiariver](https://github.com/sepiariver)