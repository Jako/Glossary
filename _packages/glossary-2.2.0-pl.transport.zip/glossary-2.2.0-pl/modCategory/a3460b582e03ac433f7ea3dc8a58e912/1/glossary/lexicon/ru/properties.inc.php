<?php
$_lang['prop_glossary.outerTpl_desc'] = 'Чанк для списка терминов';
$_lang['prop_glossary.groupTpl_desc'] = 'Чанк для групп терминов';
$_lang['prop_glossary.termTpl_desc'] = 'Чанк для терминов';
$_lang['prop_glossary.showNav_desc'] = 'Показать алфавитный указатель';
$_lang['prop_glossary.navOuterTpl_desc'] = 'Чанк для алфавитного указателя';
$_lang['prop_glossary.navItemTpl_desc'] = 'Чанк для букв в алфавитном указателе';
