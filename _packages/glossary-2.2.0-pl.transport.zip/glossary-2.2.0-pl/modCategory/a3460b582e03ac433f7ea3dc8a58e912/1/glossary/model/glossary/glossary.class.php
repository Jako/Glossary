<?php
class Glossary extends xPDOSimpleObject {}