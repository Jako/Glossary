<?php
require_once (dirname(__FILE__, 2) . '/term.class.php');
class Term_mysql extends Term {}