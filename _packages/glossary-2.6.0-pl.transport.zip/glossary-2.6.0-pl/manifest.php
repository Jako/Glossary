<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS
',
    'readme' => '# Glossary

Manage glossary terms and add them to your site

- Authors: Alan Pich <alan.pich@gmail.com>, Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2

## Features

- Custom Manager Page for managing a list of explanations for key terms in your site
- Plugin for replacing each glossary term on a MODX resource with the glossary term and the description
- Snippet to display the full glossary on a MODX resource

## Installation

MODX Package Management

## Documentation

For more information please read the [documentation](https://jako.github.io/Glossary/).

## GitHub Repository

https://github.com/Jako/Glossary
',
    'changelog' => '# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.6.0] - 2026-11-11

### Fixed

- Validate the characters of a Glossary term again
- Don\'t replace terms in html attributes, comments and entities, scripts, styles, textareas, MODX tags and in longer terms
- Don\'t replace terms in static resources, weblinks, symlinks and non html resources
- Highlight full word terms with special characters and allow special characters in the section markers
- Use the same unique anchor for the highlighter link and the snippet list
- Clear the resource cache when a term is changed
- Fix the default chunks and the .items placeholder of the Glossary snippet
- Fix the Enter key in the rich text editor fields and escape the term in the manager
- Fix missing lexicon entries, untrimmed setting values and PHP 8.1+ deprecation notices

## [2.5.1] - 2022-11-30

### Changed

- Compatibility with Redactor

## [2.5.0] - 2021-12-29

### Changed

- Code refactoring
- Full MODX 3 compatibility

## [2.4.4] - 2021-12-28

### Added

- Sort the grouped by letter terms alphabetical in the Glossary snippet output

## [2.4.3] - 2020-11-17

### Added

- showEmptySections snippet property for the Glossary snippet

### Changed

- Fix an error with invalid anchor tag characters

## [2.4.2] - 2019-03-20

### Changed

- Set the glossary.resid system setting during install by setup options

## [2.4.1] - 2019-03-20

### Changed

- Quote the regular expression delimiter in the Glossary term
- Check permission instead of usergroup for displaying the Glossary system setting tab

## [2.4.0] - 2018-01-16

### Added

- Don\'t replace Glossary terms in definable html tags
- Don\'t replace Glossary terms in all html tag attributes

## [2.3.0] - 2018-12-15

### Added

- Don\'t replace Glossary terms in definable html tag attributes
- System settings for sectionsStart and sectionsEnd
- Edit Glossary system settings in the custom manager page

## [2.2.1] - 2017-11-30

### Changed

- Bugfix for duplicated entries in the glossary overview

## [2.2.0] - 2017-02-20

### Added

- Output the result to custom placeholders via the toPlaceholder property

## [2.1.0] - 2016-10-19

### Added

- Use a Rich Text Editor for the explanation, if a MODX RTE is installed and the Glossary system setting html is enabled
- Use bootstrap data attributes for tooltip generation in the default templates

## [2.0.2] - 2016-06-09

### Changed

- Don\'t replace terms nested in explanations of another term

## [2.0.1] - 2016-06-06

### Added

- Restrict the term replacements to marked sections, if that option is enabled in the MODX system settings
- Terms starting with a special char are sorted into the character group according to the MODX translit result

## [2.0.0] - 2016-05-30

### Added

- Replace only full words of a glossary term in the resource content (could be disabled by a MODX system setting)
- Restrict the chars of the glossary term to letters, numbers, a space and the following characters: :.;,-_
- MySQL 5.7 compatibility
- Generate the transport package with GPM
- Uglify manager javascripts

### Changed

- Change the plugin properties to MODX system settings, since the system settings will survive package updates
- Improve and refactor the code

## [1.1.0] - 2018-11-30

### Added

- Transport package

### Changed

- Output templateable by chunks
',
    'setup-options' => 'glossary-2.6.0-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.2',
      'modx' => '>=2.8',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '782ff46a38f2d387aa88b1a74c4b75ea',
      'native_key' => 'glossary',
      'filename' => 'modNamespace/2c48f4241ef52f1724919b46bcf05c6a.vehicle',
      'namespace' => 'glossary',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bb9f20580bed6bc4b0fb2d73171c2fe',
      'native_key' => 'glossary.debug',
      'filename' => 'modSystemSetting/0ea3d989f34be462f8507c19d9a25d21.vehicle',
      'namespace' => 'glossary',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6d7ecf388a2c211563d1188d750c83a',
      'native_key' => 'glossary.resid',
      'filename' => 'modSystemSetting/2f6446e28a8e453219795de04b147244.vehicle',
      'namespace' => 'glossary',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c4cff5b35667235d499ceb11b0bde79',
      'native_key' => 'glossary.tpl',
      'filename' => 'modSystemSetting/bc6ae8714d3e9e7adba3118b5e5f499a.vehicle',
      'namespace' => 'glossary',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23607469e5cb6fabbe2332da5c124b5c',
      'native_key' => 'glossary.fullwords',
      'filename' => 'modSystemSetting/68924517b7cd14adfd069abd3f7d0d54.vehicle',
      'namespace' => 'glossary',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6087eb4a6899f3bdfcee1a127d70ef0a',
      'native_key' => 'glossary.sectionsStart',
      'filename' => 'modSystemSetting/80fd2ef3b161ce4de6fa42e19478a2c9.vehicle',
      'namespace' => 'glossary',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ef68a8f8914af33c68fcd6b21b65f50',
      'native_key' => 'glossary.sectionsEnd',
      'filename' => 'modSystemSetting/dad06441a9806d868624098d8dae6127.vehicle',
      'namespace' => 'glossary',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cc14f464381e73c1b7d111978abc621',
      'native_key' => 'glossary.disabledTags',
      'filename' => 'modSystemSetting/e9fdc7cf08715081b3ebaad752be13a8.vehicle',
      'namespace' => 'glossary',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75519d8f7c5999e3d8817b85d3ea3f00',
      'native_key' => 'glossary.sections',
      'filename' => 'modSystemSetting/20500c0f86de0e1a76ab2cdbd5705881.vehicle',
      'namespace' => 'glossary',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22ccded8be58ed8163a09cabc33752ad',
      'native_key' => 'glossary.html',
      'filename' => 'modSystemSetting/84d3e77c9e455da77aaeeb492b6ec86a.vehicle',
      'namespace' => 'glossary',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0d1e8ca72b283aa98b598841147aec24',
      'native_key' => NULL,
      'filename' => 'modCategory/9956a364b73bbab916fc9231e56a25ee.vehicle',
      'namespace' => 'glossary',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '02a8eb993f38ad4523f1988fe3f4ef85',
      'native_key' => 'glossary.menu',
      'filename' => 'modMenu/6c897f46478e0f7b9b9f24786a05d161.vehicle',
      'namespace' => 'glossary',
    ),
  ),
);